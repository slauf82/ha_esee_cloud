class KameraWheelZoom extends HTMLElement {
  setConfig(config) {
    this.config = {
      entity: config.entity || "input_number.kamera_digital_zoom",
      min: Number(config.min ?? 1),
      max: Number(config.max ?? 4),
      step: Number(config.step ?? 0.25)
    };
    this.style.display = "block";
    this.style.height = "0";
    this.style.margin = "0";
    this.style.padding = "0";
  }

  set hass(hass) {
    this._hass = hass;
    this._ensureGlobal();
    this._syncZoom();
    if (!this._observer) {
      this._observer = new MutationObserver(() => {
        this._installNormalView();
        this._installFullscreen();
        this._syncZoom();
      });
      this._observer.observe(document.documentElement, {childList:true, subtree:true});
    }
    requestAnimationFrame(() => {
      this._installNormalView();
      this._installFullscreen();
      this._syncZoom();
    });
  }

  disconnectedCallback() {
    if (this._observer) this._observer.disconnect();
  }

  _ensureGlobal() {
    if (document.getElementById("kamera-wheel-zoom-style")) return;
    const st=document.createElement("style");
    st.id="kamera-wheel-zoom-style";
    st.textContent=`
      .kamera-fullscreen-controls {
        position: fixed; z-index: 2147483647; right: 28px; bottom: 28px;
        display:flex; gap:12px; align-items:center;
      }
      .kamera-fullscreen-controls button {
        width:58px; height:58px; border-radius:50%; border:2px solid white;
        background:rgba(0,0,0,.68); color:white; font-size:27px;
        cursor:pointer; box-shadow:0 2px 12px rgba(0,0,0,.65);
      }
      .kamera-fullscreen-controls .level {
        color:white; background:rgba(0,0,0,.68); padding:9px 13px;
        border-radius:18px; font:600 14px sans-serif;
      }`;
    document.head.appendChild(st);
  }

  _deepElements(root=document) {
    const all=[];
    const walk=n=>{
      if (!n) return;
      if (n.querySelectorAll) {
        for(const e of n.querySelectorAll("*")) {
          all.push(e);
          if(e.shadowRoot) walk(e.shadowRoot);
        }
      }
    };
    walk(root);
    return all;
  }

  _installNormalView() {
    for(const e of this._deepElements()) {
      if((e.tagName||"").toLowerCase()==="hui-picture-entity-card" && !e.__kameraWheelZoom) {
        e.__kameraWheelZoom=true;
        e.addEventListener("wheel", ev=>this._wheel(ev), {passive:false});
      }
    }
  }

  _fullscreenTarget() {
    const fs=document.fullscreenElement;
    if (fs) return fs;
    // HA more-info/lightbox dialogs may emulate fullscreen without Fullscreen API.
    const els=this._deepElements();
    return els.find(e => {
      const tag=(e.tagName||"").toLowerCase();
      return tag==="ha-dialog" || tag==="hui-image" || tag==="ha-more-info-dialog";
    }) || null;
  }

  _installFullscreen() {
    const target=this._fullscreenTarget();
    if(!target) {
      document.querySelectorAll(".kamera-fullscreen-controls").forEach(e=>e.remove());
      return;
    }
    if(!target.__kameraWheelZoomFS) {
      target.__kameraWheelZoomFS=true;
      target.addEventListener("wheel", ev=>this._wheel(ev), {passive:false});
    }
    if(document.querySelector(".kamera-fullscreen-controls")) return;

    const c=document.createElement("div");
    c.className="kamera-fullscreen-controls";
    const minus=document.createElement("button"); minus.textContent="−"; minus.title="Zoom −";
    const level=document.createElement("span"); level.className="level";
    const plus=document.createElement("button"); plus.textContent="+"; plus.title="Zoom +";
    minus.onclick=e=>{e.preventDefault();e.stopPropagation();this._change(-this.config.step)};
    plus.onclick=e=>{e.preventDefault();e.stopPropagation();this._change(this.config.step)};
    c.append(minus,level,plus);
    document.body.appendChild(c);
    this._syncZoom();
  }

  _wheel(ev) {
    // Only consume wheel when a camera/fullscreen viewer is the interaction target.
    ev.preventDefault(); ev.stopPropagation();
    this._change(ev.deltaY < 0 ? this.config.step : -this.config.step);
  }

  async _change(delta) {
    if(!this._hass) return;
    let v=Number(this._hass.states[this.config.entity]?.state ?? 1);
    if(!Number.isFinite(v)) v=1;
    v=Math.max(this.config.min,Math.min(this.config.max,v+delta));
    v=Math.round(v/this.config.step)*this.config.step;
    await this._hass.callService("input_number","set_value",{entity_id:this.config.entity,value:v});
  }

  _syncZoom() {
    if(!this._hass) return;
    const v=Number(this._hass.states[this.config.entity]?.state ?? 1);
    document.querySelectorAll(".kamera-fullscreen-controls .level").forEach(e=>e.textContent=`${v.toFixed(2).replace(/\.00$/,"")}×`);
    const target=this._fullscreenTarget();
    if(!target) return;
    // Scale the actual visual media, not the control overlay.
    for(const e of this._deepElements(target)) {
      const tag=(e.tagName||"").toLowerCase();
      if(tag==="img" || tag==="video" || tag==="ha-camera-stream") {
        e.style.transform=`scale(${v})`;
        e.style.transformOrigin="center center";
        e.style.transition="transform .20s ease";
      }
    }
  }

  getCardSize(){return 0;}
}
if(!customElements.get("kamera-wheel-zoom")) customElements.define("kamera-wheel-zoom",KameraWheelZoom);
