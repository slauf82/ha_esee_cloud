Kamera-Dashboard – Digitalzoom inkl. Vollbild
================================================
- 4er-Ansicht: weißer Rahmen um die ausgewählte PTZ-Kamera.
- Einzelansicht: HD, ohne Auswahlrahmen.
- Normalansicht: Zoom +/- UND Mausrad.
- Vollbild des Einzelbildes: schwebende Zoom - / Zoom + Buttons UND Mausrad.
- Beide Ansichten verwenden denselben Zoomwert (1x–4x, Schritt 0,25x).
- 8er-Ansicht, PIN-Sperre und echte PTZ-Steuerung bleiben unverändert.

Installation/Update:
1. dashboard_kameras.yaml übernehmen.
2. input_number.yaml wie bisher übernehmen/einbinden.
3. kamera-wheel-zoom.js nach /config/www/kamera-wheel-zoom.js kopieren und die alte Datei ersetzen.
4. Ressource bleibt: /local/kamera-wheel-zoom.js, Typ JavaScript-Modul.
5. Danach Browser-Cache hart neu laden (Strg+F5). Bei der Companion App Frontend neu laden.

Wichtig:
Der Vollbild-Zoom wird im Browser erzeugt; es geht kein Zoomkommando an die Kamera.
